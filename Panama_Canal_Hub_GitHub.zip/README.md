# Panama Canal Intelligence Hub — no API keys

This is a public-source, API-key-free GitHub Pages website. GitHub Actions checks ACP listing pages every 3 hours (scheduled jobs may be delayed), downloads PDFs, extracts text, and stores SHA-256-versioned records in `data/notices.json`. The site searches locally in the browser. **It does not provide AI-generated answers, validated effective regulations, or automatic Korean translations.** Never treat its search results as legal/regulatory clearance.

## Deploy
1. Create a GitHub account and **public** repository, e.g. `panama-canal-hub`.
2. Upload all contents of this ZIP to the repository root, including `.github/workflows` (use GitHub web upload or local git). Commit to `main`.
3. Settings > Actions > General > Workflow permissions: allow Read and write permissions, if needed to allow archive commits. Organizational policy may restrict this.
4. Settings > Pages > Build and deployment > Source: GitHub Actions.
5. Actions > Collect ACP documents > Run workflow. Check log for `Documents seen` and errors. Large PDFs may cause GitHub repo size growth.
6. Actions > Publish website > Run workflow if needed. URL: `https://YOUR-USERNAME.github.io/panama-canal-hub/` (repository name may vary).

## Important limits
- ACP markup may change, block bots, or use links not captured by the scraper; verify collector logs and document counts.
- PDF text extraction may omit tables, scans and charts; no OCR is performed.
- Full PDF text and revisions in Git history can make the repository large; optimize storage before long-term use.
- `last_seen` is updated each run; that creates commits even with no changes. For large-scale use, change collector to update it only on meaningful change.
- A new version sets `needs_review`. The website **does not** automatically determine currently applicable regulations.
- The site and archive are PUBLIC. Do not add internal voyage information, contracts, or private annotations.
- GitHub Pages and Actions limits, scheduled workflow delays, and possible automatic disabling on inactive repositories apply.
