import json, re, hashlib, io, datetime, pathlib, time
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup
from pypdf import PdfReader
ROOT=pathlib.Path(__file__).parent
DB=ROOT/'data'/'notices.json'
SOURCES={'Advisory':'https://pancanal.com/en/maritime-services/advisory-to-shipping/','Notice':'https://pancanal.com/en/maritime-services/notices-to-shipping/'}
S=requests.Session(); S.headers.update({'User-Agent':'Mozilla/5.0 (compatible; ACP-Document-Archive/1.0)'})
def fetch(url):
 r=S.get(url,timeout=35);r.raise_for_status();return r.content

def main():
 records=json.loads(DB.read_text(encoding='utf8')) if DB.exists() else {}
 seen=0;changed=0;errors=[]
 for kind,url in SOURCES.items():
  try: soup=BeautifulSoup(fetch(url),'html.parser')
  except Exception as e: errors.append(f'{kind} listing: {e}');continue
  links=[]
  for a in soup.select('a[href]'):
   label=' '.join(a.get_text(' ',strip=True).split()); href=urljoin(url,a['href'])
   match=re.search(r'\b([AN])-\s*(\d{1,2})\s*-\s*(20\d{2})\b',label,re.I)
   if not match or match.group(1).upper()!=kind[0]: continue
   docid=f'{match.group(1).upper()}-{int(match.group(2)):02d}-{match.group(3)}'
   if not any(x[0]==docid for x in links):links.append((docid,label,href))
  if not links:errors.append(f'{kind}: no documents discovered');continue
  for docid,title,href in links:
   seen+=1; old=records.get(docid,{}); entry=dict(old)
   entry.update({'id':docid,'kind':kind,'title':title,'source_page':url,'url':href,'last_seen':old.get('last_seen') or datetime.datetime.now(datetime.timezone.utc).isoformat()})
   try:
    raw=fetch(href); digest=hashlib.sha256(raw).hexdigest()
    if digest!=old.get('sha256'):
     text=''
     if raw[:4]==b'%PDF':
      pdf=PdfReader(io.BytesIO(raw));text='\n'.join((p.extract_text() or '') for p in pdf.pages)
     else:text=BeautifulSoup(raw,'html.parser').get_text(' ',strip=True)
     versions=old.get('versions',[])
     versions.append({'sha256':digest,'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':text[:250000],'pages':len(pdf.pages) if raw[:4]==b'%PDF' else None})
     entry.update({'sha256':digest,'versions':versions,'review_status':'needs_review','updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()});changed+=1
   except Exception as e:errors.append(f'{docid}: {e}')
   records[docid]=entry
   time.sleep(.15)
 DB.parent.mkdir(exist_ok=True);DB.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
 print(f'Documents seen: {seen}; new/changed: {changed}; errors: {len(errors)}')
 if errors: print('\n'.join(errors[:30]))
 if seen==0:raise RuntimeError('No ACP listings successfully parsed')
if __name__=='__main__':main()
